package com.ecommerce.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.entity.Warehouse;

@Repository("warehouseDAO")
@Transactional
public class WarehouseDAOImpl implements WarehouseDAO{
	
	
	@PersistenceContext
	public EntityManager entityManager;

	@Transactional(readOnly=false)
	public Warehouse addWarehouse(Warehouse warehouse) {
		
		entityManager.persist(warehouse);
		return warehouse;
	}

	@Transactional(readOnly=false)
	public Warehouse updateWarehouse(Warehouse warehouse) {
		entityManager.merge(warehouse);
		return warehouse;
	}

	@Transactional(readOnly=false)
	public int deleteWarehouse(long warehouseId) {
		return entityManager.createQuery("delete from warehouse where WID = " + warehouseId).executeUpdate();
		
	}

	@Transactional(readOnly=true)
	public Warehouse getWarehouse(long warehouseId) {
		String sql = "select warehouse from Warehouse warehouse where warehouse.warehouseId="+warehouseId;
		try{
			return (Warehouse) entityManager.createQuery(sql).getSingleResult();
		}catch(Exception e){
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly=true)
	public List<Warehouse> getWarehouses() {
		
		return entityManager.createQuery("select warehouse from Warehouse warehouse").getResultList();
	}

}
