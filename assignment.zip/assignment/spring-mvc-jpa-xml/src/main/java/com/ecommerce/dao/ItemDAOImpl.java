package com.ecommerce.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.entity.Item;

@Repository("itemDAO")
@Transactional
public class ItemDAOImpl implements ItemDAO{
	
	
	@PersistenceContext
	public EntityManager entityManager;

	@Transactional(readOnly=false)
	public Item addItem(Item item) {
		
		entityManager.persist(item);
		return item;
	}

	@Transactional(readOnly=false)
	public Item updateItem(Item item) {
		entityManager.merge(item);
		return item;
	}

	@Transactional(readOnly=false)
	public void deleteItem(long itemId) {
	}
	
	@Transactional(readOnly=false)
	public List<Item> getAllAvailableSizes(long itemId) {
		return getAllAvailableSizes(itemId);
	}

	@Transactional(readOnly=true)
	public Item getItem(long itemId) {
		String sql = "select item from Item item where item.itemId="+itemId;
		try{
			return (Item) entityManager.createQuery(sql).getSingleResult();
		}catch(Exception e){
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly=true)
	public List<Item> getItems() {
		
		return entityManager.createQuery("select item from Item item").getResultList();
	}

}
