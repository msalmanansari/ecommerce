package com.ecommerce.ui.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ecommerce.entity.Warehouse;
import com.ecommerce.services.WarehouseService;

@Controller
@RequestMapping("/warehouse")
public class WarehouseController {
	
	Logger  LOG = Logger.getLogger(WarehouseController.class.getName());
	
	@Autowired(required=true)
	@Qualifier("warehouseService")
	private WarehouseService warehouseService;
	
	
	@GetMapping("/")
	public String getHome(){
		LOG.info("Home page invoked");
		return "redirect:warehouses.action";
	}
	
	@GetMapping("/warehouses")
	public ModelAndView getWarehouses(){
		LOG.info("Warehouse page invoked");
		ModelAndView model  = new ModelAndView("warehouses");
		List<Warehouse> list = warehouseService.getAllWarehouses();
		model.addObject("warehouses", list);
		return model;
	}
	@GetMapping("/editWarehouseView/{warehouseId}")
	public ModelAndView getEditWarehouseForm(@PathVariable("warehouseId") String warehouseId){
		
		
		ModelAndView model  = new ModelAndView("editWarehouse");
		Warehouse cus = warehouseService.getWarehouse(Long.parseLong(warehouseId));
		model.addObject("warehouse", cus);
		return model;
		
	}
	@RequestMapping(value="/editWarehouse",method=RequestMethod.POST)
	public ModelAndView editWarehouse(HttpServletRequest request,HttpServletResponse response){
		
		ModelAndView model = new ModelAndView();
		model.setViewName("warehouses");
		String warehouseId = request.getParameter("warehouseId");
		String name = request.getParameter("name");
		String warehouseAddress = request.getParameter("address");
		String country = request.getParameter("country");
		LOG.info("Editing warehouse with name:"+name);
		Warehouse warehouse = warehouseService.updateWarehouse(Long.parseLong(warehouseId),name, warehouseAddress, country);
		if(warehouse!=null){
			model.addObject("saveSuccess", "Warehouse Added SuccessFully:"+warehouse.getName());
		}else{
			model.addObject("saveError", "Warehouse creation failed");
		}
		List<Warehouse> list = warehouseService.getAllWarehouses();
		model.addObject("warehouses", list);
		
		return model;
		
	}
	@RequestMapping(value="/addWarehouse",method=RequestMethod.POST)
	public ModelAndView addWarehouse(HttpServletRequest request,HttpServletResponse response){
		
		ModelAndView model = new ModelAndView();
		model.setViewName("warehouses");
		String warehouseId = request.getParameter("warehouseId");
		String name = request.getParameter("name");
		String warehouseAddress = request.getParameter("address");
		String country = request.getParameter("country");
		LOG.info("Adding warehouse with name:"+name);
		Warehouse warehouse = warehouseService.addWarehouse(name, warehouseAddress, country);
		
		if(warehouse!=null){
			model.addObject("saveSuccess", "Warehouse Added SuccessFully:"+warehouse.getName());
		}else{
			model.addObject("saveError", "Warehouse creation failed");
		}
		List<Warehouse> list = warehouseService.getAllWarehouses();
		model.addObject("warehouses", list);
		
		return model;
		
	}
	
	@RequestMapping(value="/deleteWarehouse",method=RequestMethod.POST)
	public ModelAndView deleteWarehouse(HttpServletRequest request,HttpServletResponse response){
		
		ModelAndView model = new ModelAndView();
		model.setViewName("warehouses");
		long warehouseId = Long.parseLong(request.getParameter("warehouseId"));
		String name = request.getParameter("name");
		LOG.info("Deleting warehouse with name:"+name);
		int isDeleted = warehouseService.deleteWarehouse(warehouseId);
		
		if(isDeleted == 1){
			model.addObject("saveSuccess", "Warehouse Added SuccessFully:"+name);
		}else{
			model.addObject("saveError", "Warehouse creation failed");
		}
		List<Warehouse> list = warehouseService.getAllWarehouses();
		model.addObject("warehouses", list);
		
		return model;
		
	}
	
	
}
