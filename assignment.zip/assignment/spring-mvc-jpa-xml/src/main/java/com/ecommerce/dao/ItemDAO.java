package com.ecommerce.dao;

import java.util.List;

import com.ecommerce.entity.Item;

public interface ItemDAO {
	
	public Item addItem(Item item);
	public Item updateItem(Item item);
	public void deleteItem(long itemId);
	public Item getItem(long itemId);
	public List<Item> getItems();
	public List<Item> getAllAvailableSizes(long itemId);

}
