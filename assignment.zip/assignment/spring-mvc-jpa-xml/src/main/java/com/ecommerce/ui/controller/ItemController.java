package com.ecommerce.ui.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ecommerce.entity.Item;
import com.ecommerce.services.ItemService;

@Controller
@RequestMapping("/item")
public class ItemController {
	
	Logger  LOG = Logger.getLogger(ItemController.class.getName());
	
	@Autowired(required=true)
	@Qualifier("itemService")
	private ItemService itemService;
	
	
	@GetMapping("/")
	public String getHome(){
		LOG.info("Home page invoked");
		return "redirect:items.action";
	}
	
	@GetMapping("/items")
	public ModelAndView getItems(){
		LOG.info("Item page invoked");
		ModelAndView model  = new ModelAndView("items");
		List<Item> list = itemService.getAllItems();
		model.addObject("items", list);
		return model;
	}
	@GetMapping("/editItemView/{itemId}")
	public ModelAndView getEditItemForm(@PathVariable("itemId") String itemId){
		
		
		ModelAndView model  = new ModelAndView("editItem");
		Item cus = itemService.getItem(Long.parseLong(itemId));
		model.addObject("item", cus);
		return model;
		
	}
	@RequestMapping(value="/editItem",method=RequestMethod.POST)
	public ModelAndView editItem(HttpServletRequest request,HttpServletResponse response){
		
		ModelAndView model = new ModelAndView();
		model.setViewName("items");
		long itemId = Long.parseLong(request.getParameter("itemId"));
		String itemName = request.getParameter("iname");
		String itemType = request.getParameter("itemType");
		String itemSize = request.getParameter("itemSize");
		int minOrderQty = Integer.parseInt(request.getParameter("moq"));
		int qtyPerBox = Integer.parseInt(request.getParameter("qpb"));
		int reOrderPoint = Integer.parseInt(request.getParameter("reop"));
		int inStock = Integer.parseInt(request.getParameter("inStock"));
		int availablqty = Integer.parseInt(request.getParameter("availablqty"));
		LOG.info("Adding item with name:"+itemName);
		Item item = itemService.updateItem(itemId, itemName, itemType, itemSize, minOrderQty, qtyPerBox, reOrderPoint, inStock, availablqty);
		if(item!=null){
			model.addObject("saveSuccess", "Item Added SuccessFully:"+item.getIname());
		}else{
			model.addObject("saveError", "Item creation failed");
		}
		List<Item> list = itemService.getAllItems();
		model.addObject("items", list);
		
		return model;
		
	}
	
	@RequestMapping(value="/addItem",method=RequestMethod.POST)
	public ModelAndView addItem(HttpServletRequest request,HttpServletResponse response){
		
		ModelAndView model = new ModelAndView();
		model.setViewName("items");
		long itemId = Long.parseLong(request.getParameter("itemId"));
		String itemName = request.getParameter("iname");
		String itemType = request.getParameter("itemType");
		String itemSize = request.getParameter("itemSize");
		int minOrderQty = Integer.parseInt(request.getParameter("moq"));
		int qtyPerBox = Integer.parseInt(request.getParameter("qpb"));
		int reOrderPoint = Integer.parseInt(request.getParameter("reop"));
		int inStock = Integer.parseInt(request.getParameter("inStock"));
		int availablqty = Integer.parseInt(request.getParameter("availablqty"));
		LOG.info("Adding item with name:"+itemName);
		Item item = itemService.addItem(itemName, itemType, itemSize, minOrderQty, qtyPerBox, reOrderPoint, inStock, availablqty);
		if(item!=null){
			model.addObject("saveSuccess", "Item Added SuccessFully:"+item.getIname());
		}else{
			model.addObject("saveError", "Item creation failed");
		}
		List<Item> list = itemService.getAllItems();
		model.addObject("items", list);
		
		return model;
		
	}
	
	@RequestMapping(value="/deleteItem",method=RequestMethod.POST)
	public ModelAndView deleteItem(HttpServletRequest request,HttpServletResponse response){
		
		ModelAndView model = new ModelAndView();
		model.setViewName("items");
		long itemId = Long.parseLong(request.getParameter("itemId"));
		String itemName = request.getParameter("iname");


		LOG.info("Deleting item with name:"+itemName);
		boolean isDeleted = itemService.deleteItem(itemId);
		if(isDeleted){
			model.addObject("deleteSuccess", "Item deleted SuccessFully:"+itemName);
		}else{
			model.addObject("deleteError", "Item deletion failed");
		}
		List<Item> list = itemService.getAllItems();
		model.addObject("items", list);
		
		return model;
		
	}
}
