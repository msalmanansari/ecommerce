package com.ecommerce.services;

import java.util.List;

import com.ecommerce.entity.Warehouse;

public interface WarehouseService {
	
	public Warehouse addWarehouse(String warehouseName, String address, String country);
	public Warehouse updateWarehouse(long warehouseId,String warehouseName, String address, String country);
	public int deleteWarehouse(long warehouseId);
	public Warehouse getWarehouse(long warehouseId);
	public List<Warehouse> getAllWarehouses();
}
