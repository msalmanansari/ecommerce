package com.ecommerce.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="item")
public class Item {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long IId;
  
    @Column(name = "INAME", nullable = false)
    private String Iname;
    
    @Column(name = "ITYPE", nullable = false)
    private String itype;
    
    @Column(name = "iSIZE", nullable = false)
    private String isize;

    @Column(name = "MOQ", nullable = false)
    private int moq;
    
    @Column(name = "QPB", nullable = false)
    private int qpb;

    @Column(name = "REOP", nullable = false)
    private int reop;

    @Column(name = "INSTOCK", nullable = false)
    private int instock;

    @Column(name = "AVAILABLEQTY", nullable = false)
    private int availableqty;

	public long getIId() {
		return IId;
	}

	public void setIId(long iId) {
		IId = iId;
	}

	public String getIname() {
		return Iname;
	}

	public void setIname(String iname) {
		Iname = iname;
	}

	public String getItype() {
		return itype;
	}

	public void setItype(String itype) {
		this.itype = itype;
	}

	public String getIsize() {
		return isize;
	}

	public void setIsize(String isize) {
		this.isize = isize;
	}

	public int getMoq() {
		return moq;
	}

	public void setMoq(int moq) {
		this.moq = moq;
	}

	public int getQpb() {
		return qpb;
	}

	public void setQpb(int qpb) {
		this.qpb = qpb;
	}

	public int getReop() {
		return reop;
	}

	public void setReop(int reop) {
		this.reop = reop;
	}

	public int getInstock() {
		return instock;
	}

	public void setInstock(int instock) {
		this.instock = instock;
	}

	public int getAvailableqty() {
		return availableqty;
	}

	public void setAvailableqty(int availableqty) {
		this.availableqty = availableqty;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (IId ^ (IId >>> 32));
		result = prime * result + ((Iname == null) ? 0 : Iname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (IId != other.IId)
			return false;
		if (Iname == null) {
			if (other.Iname != null)
				return false;
		} else if (!Iname.equals(other.Iname))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Item [IId=" + IId + ", Iname=" + Iname + ", itype=" + itype
				+ ", isize=" + isize + ", moq=" + moq + ", qpb=" + qpb
				+ ", reop=" + reop + ", instock=" + instock + ", availableqty="
				+ availableqty + "]";
	}
	
}
