package com.ecommerce.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.dao.ItemDAO;
import com.ecommerce.entity.Item;

@Service("itemService")
@Transactional
public class ItemServiceImpl implements ItemService {

	@Autowired(required=true)
	@Qualifier("itemDAO")
	private ItemDAO itemDAO;
	
	@Transactional
	public Item addItem(String itemName, String itemType, String itemSize, int minOrderQty, int qtyPerBox, int reOrderPoint, int inStock, int availablQty){
		
		System.out.println("Item Service create invoked:"+itemName);
		Item item  = new Item();item.setIname(itemName);
		item.setIname(itemType);
		item.setIsize(itemSize);
		item.setMoq(minOrderQty);
		item.setQpb(qtyPerBox);
		item.setReop(reOrderPoint);
		item.setInstock(inStock);
		item.setAvailableqty(availablQty);
		item = itemDAO.updateItem(item);
		return item;
	}
	@Transactional
	public Item updateItem(long itemId, String itemName, String itemType, String itemSize, int minOrderQty, int qtyPerBox, int reOrderPoint, int inStock, int availablQty) {
		
		System.out.println("Item Service Update invoked:"+itemName);
		Item item  = new Item();
		item.setIId(itemId);
		item.setIname(itemName);
		item.setIname(itemType);
		item.setIsize(itemSize);
		item.setMoq(minOrderQty);
		item.setQpb(qtyPerBox);
		item.setReop(reOrderPoint);
		item.setInstock(inStock);
		item.setAvailableqty(availablQty);
		item = itemDAO.updateItem(item);
		return item;
	}

	public Item getItem(long itemId) {
		return itemDAO.getItem(itemId);
	}

	public List<Item> getAllItems() {
		return itemDAO.getItems();
	}
	@Override
	public boolean deleteItem(long itemId) {
		itemDAO.deleteItem(itemId);
		return false;
	}
	@Override
	public List<Item> getAllAvailableSizes(long itemId) {
		// TODO Auto-generated method stub
		itemDAO.getAllAvailableSizes(itemId);
		return null;
	}
}
