package com.ecommerce.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.dao.WarehouseDAO;
import com.ecommerce.entity.Warehouse;

@Service("warehouseService")
@Transactional
public class WarehouseServiceImpl implements WarehouseService {

	@Autowired(required=true)
	@Qualifier("warehouseDAO")
	private WarehouseDAO warehouseDAO;
	
	@Transactional
	public Warehouse addWarehouse(String warehouseName, String address, String country) {
		
		System.out.println("Warehouse Service create invoked:"+warehouseName);
		Warehouse warehouse  = new Warehouse();
		warehouse.setName(warehouseName);
		warehouse.setAddress(address);
		warehouse = warehouseDAO.addWarehouse(warehouse);
		return warehouse;
	}
	@Transactional
	public Warehouse updateWarehouse(long warehouseId,String warehouseName, String address, String country) {
		
		System.out.println("Cusomer Service Update invoked:"+warehouseName);
		Warehouse warehouse  = new Warehouse();
		warehouse.setWid(Integer.parseInt(warehouseId+""));
		warehouse.setName(warehouseName);
		return warehouse;
	}

	public Warehouse getWarehouse(long warehouseId) {
		return warehouseDAO.getWarehouse(warehouseId);
	}

	public List<Warehouse> getAllWarehouses() {
		return warehouseDAO.getWarehouses();
	}
	@Override
	public int deleteWarehouse(long warehouseId) {
		return warehouseDAO.deleteWarehouse(warehouseId);
//		return false;
	}


}
