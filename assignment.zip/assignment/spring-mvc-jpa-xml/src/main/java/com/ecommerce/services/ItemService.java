package com.ecommerce.services;

import java.util.List;

import com.ecommerce.entity.Item;

public interface ItemService {
	
	public Item addItem(String itemName, String itemType, String sizeName, int minOrderQty, int qtyPerBox, int reOrderPoint, int inStock, int availablqty);
	public Item updateItem(long itemId, String itemName, String itemType, String sizeName, int minOrderQty, int qtyPerBox, int reOrderPoint, int inStock, int availablqty);
	public Item getItem(long itemId);
	public boolean deleteItem(long itemId);
	public List<Item> getAllItems();
	public List<Item> getAllAvailableSizes(long itemId);
}
