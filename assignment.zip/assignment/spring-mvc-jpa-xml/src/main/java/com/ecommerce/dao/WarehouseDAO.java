package com.ecommerce.dao;

import java.util.List;

import com.ecommerce.entity.Warehouse;

public interface WarehouseDAO {
	
	public Warehouse addWarehouse(Warehouse item);
	public Warehouse updateWarehouse(Warehouse item);
	public int deleteWarehouse(long itemId);
	public Warehouse getWarehouse(long itemId);
	public List<Warehouse> getWarehouses();

}
